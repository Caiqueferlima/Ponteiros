#include <stdio.h>

void troca(int *x, int *y, int *z);

int main()
{
    int a, b, c;
    a = 5;
    b = 3;
    c = 4;
    troca(&a,&b,&c);
    printf("a = %d, b = %d, c = %d \n", a, b, c);

    return 0;
}
void troca(int *x, int *y, int *z){
    int aux;
    aux = *x;
    *x = *y;
    *y = *z;
    *z = aux;
}
